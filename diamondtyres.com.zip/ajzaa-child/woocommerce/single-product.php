<?php
/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
get_header('shop'); ?>

<style>
    .row-product {
    margin: 0 auto;
    /* max-width: 82.5rem; */
    width: 100%;
}
    .row-product-2 {
    margin: 0 auto;
     max-width: 101.5rem; 
    width: 100%;
}
</style>


	<!--<section class="wd-title-bar">-->
	<!--	<div class="row">-->
	<!--		<div class="large-12 columns wd-title-section_l">-->
	<!--			<h2><?php //woocommerce_page_title(); ?></h2>-->
	<!--		</div>-->
	<!--	</div>-->
	<!--</section>-->
	<div class="p-t-30"></div>
	<div class="row">
		<div class="large-12 small-12 columns">
				<?php while(have_posts()) : the_post(); ?>

					<?php wc_get_template_part('content', 'single-product'); ?>

				<?php endwhile; // end of the loop. ?>
		</div>
		<!--<div class="large-3 small-12 columns">
			<?php
			/**
			 * woocommerce_sidebar hook.
			 *
			 * @hooked woocommerce_get_sidebar - 10
			 */
			//do_action('woocommerce_sidebar');
			?>
		</div>-->
	</div>
	
	<div class="row-product" style="background-color:black;color:white;padding:20px;">
<style>
@media screen and (min-width: 701px){
.column {
  float: left;
  width: 50%;
}}
@media screen and (max-width: 700px){
.column {
  float: left;
  width: 100%;
}}

/* Clear floats after the columns */
.row-product:after {
  content: "";
  display: table;
  clear: both;
}

/* Style the tab */
.tab {
  text-align:center;
  overflow: hidden;
  
  /*border: 1px solid #ccc;*/
  /*background-color: #f1f1f1;*/
}

/* Style the buttons inside the tab */
.tab button {
    
    
  background-color: inherit;
  /*float: left;*/
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 15px;
  border: 1px solid #fff;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
  
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  /*border: 1px solid #ccc;*/
  border-top: none;
}


</style>
<?php
// Get $product object from product ID
 global $product;

?>

  <h2 style="color:#fff; text-align:center;"><?php echo $product->get_name(); ?></h2>
  <h4 style="color:#fff; text-align:center;">TECHNICAL ADVICES</h4>
  <div class="tab">
  <button class="tablinks" onclick="openCity(event, 'London')">Role and Positioning</button>
  <button class="tablinks" onclick="openCity(event, 'Paris')">Tread Pattern</button>
  <button class="tablinks" onclick="openCity(event, 'Tokyo')">Compound</button>
  <button class="tablinks" onclick="openCity(event, 'Lahore')">Benifits</button>
</div>
<div id="London" class="tabcontent">
  <div class="column">
      <h4 style="color:#fff; text-align:center;">Non TECHNICAL ADVICES</h4>
      <p>London is the capital city of England. It is the most populous city in the United Kingdom, with a metropolitan area of over 13 million inhabitants.</p>
  </div>
  <div class="column">
      <p>Standing on the River Thames, London has been a major settlement for two millennia, its history going back to its founding by the Romans, who named it Londinium.</p>
  </div>
</div>
<div id="Paris" class="tabcontent">
  <div class="column">
      <h4 style="color:#fff; text-align:center;">TECHNICAL ADVICES</h4>
      <p>London is the capital city of England. It is the most populous city in the United Kingdom, with a metropolitan area of over 13 million inhabitants.</p>
  </div>
  <div class="column">
      <p>Standing on the River Thames, London has been a major settlement for two millennia, its history going back to its founding by the Romans, who named it Londinium.</p>
  </div>
</div>
<div id="Tokyo" class="tabcontent">
  <div class="column">
      <h4 style="color:#fff; text-align:center;">TECHNICAL ADVICES</h4>
      <p>London is the capital city of England. It is the most populous city in the United Kingdom, with a metropolitan area of over 13 million inhabitants.</p>
  </div>
  <div class="column">
      <p>Standing on the River Thames, London has been a major settlement for two millennia, its history going back to its founding by the Romans, who named it Londinium.</p>
  </div>
</div>
<div id="Lahore" class="tabcontent">
  <div class="column">
      <h4 style="color:#fff; text-align:center;">TECHNICAL ADVICES</h4>
      <p>London is the capital city of England. It is the most populous city in the United Kingdom, with a metropolitan area of over 13 million inhabitants.</p>
  </div>
  <div class="column">
      <img src="http://diamondtyres.zaheercena.website/wp-content/uploads/2013/06/product-69-600x600.png">
  </div>
</div>
<!-- Row div --></div>
<!-- This is Accordian -->
<style>
/* Style the element that is used to open and close the accordion class */
p.accordion {
    /*background-color: #eee;*/
    color: #444;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    text-align: left;
    border: none;
    outline: none;
    transition: 0.4s;
    margin-bottom:10px;
    border-bottom: 2px solid #ccc;
}

/* Add a background color to the accordion if it is clicked on (add the .active class with JS), and when you move the mouse over it (hover) */
p.accordion.active, p.accordion:hover {
    /*background-color: #ddd;*/
}

/* Unicode character for "plus" sign (+) */
p.accordion:after {
    content: '\2795'; 
    font-size: 13px;
    color: #777;
    float: right;
    margin-left: 5px;
}

/* Unicode character for "minus" sign (-) */
p.accordion.active:after {
    content: "\2796"; 
}

/* Style the element that is used for the panel class */

div.panel {
    border-style: unset;
    padding: 0 18px;
    background-color: white;
    max-height: 0;
    overflow: hidden;
    transition: 0.4s ease-in-out;
    opacity: 0;
    margin-bottom:10px;
}

div.panel.show {
    opacity: 1;
    max-height: 500px; /* Whatever you like, as long as its more than the height of the content (on all screen sizes) */
}

/* This is for Sizes Section */
@media screen and (min-width: 701px){
.columnsize {
  float: left;
  width: 33.2%;
  background-color: #cccccc59;
  margin: 1px;
  
}
@media screen and (max-width: 700px){
.columnsize {
  text-align:center;
  width: 100%;
  
}}

/* Clear floats after the columns */
.rowsize:after {
  content: "";
  display: table;
  clear: both;
}
</style>


<div class="row-product-2">

     
     <?php // check if the repeater field has rows of data
if( have_rows('front_tyre_size') ):
    ?>
    <br>
    <p style="text-align:center;"><font size="6">AVAILABLE SIZES FOR YOU</font></p>
    <br>
     <p class="accordion"><font size="5"><?php the_field('front_size_heading'); ?></font>
    <font size="2">Front</font>
    </p>
<div class="panel">
  <div class="rowsize"><?php

 	// loop through the rows of data
    while ( have_rows('front_tyre_size') ) : the_row();
    ?>
     <div class="columnsize"><?php the_sub_field('size_front'); ?></div>

     <?php
    endwhile;
endif; ?>
     </div>
    
</div>     



     <?php // check if the repeater field has rows of data
if( have_rows('rear_tyre_size') ):
     ?>
     <p class="accordion"><font size="5"><?php the_field('rear_size_heading'); ?></font>
    <font size="2">Rear</font>
    </p>
    <div class="panel">
      <div class="rowsize">
      <?php

 	// loop through the rows of data
    while ( have_rows('rear_tyre_size') ) : the_row();
    ?>
     <div class="columnsize"><?php the_sub_field('size_rear'); ?></div>
     <?php
    endwhile;
endif; ?>
</div>
</div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function(event) { 


var acc = document.getElementsByClassName("accordion");
var panel = document.getElementsByClassName('panel');

for (var i = 0; i < acc.length; i++) {
    acc[i].onclick = function() {
        var setClasses = !this.classList.contains('active');
        setClass(acc, 'active', 'remove');
        setClass(panel, 'show', 'remove');

        if (setClasses) {
            this.classList.toggle("active");
            this.nextElementSibling.classList.toggle("show");
        }
    }
}

function setClass(els, className, fnName) {
    for (var i = 0; i < els.length; i++) {
        els[i].classList[fnName](className);
    }
}

});
</script>



<!-- This Section is for Below Sizes available of Product -->

	
<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>	
<?php
get_footer('shop');

   
