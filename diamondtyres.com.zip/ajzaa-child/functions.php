<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );
         
if ( !function_exists( 'child_theme_configurator_css' ) ):
    function child_theme_configurator_css() {
        wp_enqueue_style( 'chld_thm_cfg_child', trailingslashit( get_stylesheet_directory_uri() ) . 'style.css', array( 'Owl-carousel','Owl-carousel-theme','lightbox','ajzaa-lightbox','ionicons','mediaelementplayer','ajzaa_style','ajzaa_custom-style','ajzaa_custom-style' ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'child_theme_configurator_css', 10 );

// END ENQUEUE PARENT ACTION


// Remove the product description Title

//add_filter( 'woocommerce_product_description_heading', '__return_null' );
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
 
add_action( 'woocommerce_after_single_product_summary', 'bbloomer_wc_output_long_description', 10 );
 
function bbloomer_wc_output_long_description() {
?>
   <div class="woocommerce-tabs">
   <?php //the_content(); ?>
   </div>
<?php
}