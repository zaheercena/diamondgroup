<?php
/**
* @version    1.0
* @package    WR_Theme
* @author     WooRockets Team <support@woorockets.com>
* @copyright  Copyright (C) 2014 WooRockets.com. All Rights Reserved.
* @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
*
* Websites: http://www.woorockets.com
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product, $post;

$wr_nitro_options = WR_Nitro::get_options();

// Catalog mode
$wr_catalog_mode = $wr_nitro_options['wc_archive_catalog_mode'];

// Show price
$wr_show_price = $wr_nitro_options['wc_archive_catalog_mode_price'];

// Show custom button
$wr_show_button = $wr_nitro_options['wc_archive_catalog_mode_button'];

// Custom button action
$wr_show_button_action = $wr_nitro_options['wc_archive_catalog_mode_button_action'];

// Custom button action text
$wr_show_button_text = $wr_nitro_options['wc_archive_catalog_mode_button_action_simple'];

// Sticky add to cart
$sticky = $wr_nitro_options['wc_detail_mobile_sticky_cart'];

?>

<div id="product-<?php the_ID(); ?>" <?php post_class( 'style-2 single-mobile-layout' ); ?>>
	<div class="oh pdt30">
		<div id="shop-detail">
			<div class="container">
				<div class="row">
					<div class="cm-12">
						<div class="p-single-images pr clear">
							<?php
							/**
							* woocommerce_before_single_product_summary hook
							*
							* @hooked woocommerce_show_product_sale_flash - 10
							* @hooked woocommerce_show_product_images - 20
							*/
							do_action( 'woocommerce_before_single_product_summary' );
							?>
						</div>
						<div class="p-single-info pdt30 mgt30 nitro-line <?php echo $sticky ? 'fixed' : 'fc fcc' ?>">
							<?php
							if ( $wr_nitro_options['wc_single_breadcrumb'] ) {
								echo '<div class="mgb10">';
								woocommerce_breadcrumb();
								echo '</div>';
							}
							?>
							<?php
							/**
							* woocommerce_single_product_summary hook.
							*
							* @hooked woocommerce_template_single_title - 5
							* @hooked woocommerce_template_single_rating - 10
							* @hooked woocommerce_template_single_price - 10
							* @hooked woocommerce_template_single_excerpt - 20
							* @hooked woocommerce_template_single_add_to_cart - 30
							* @hooked woocommerce_template_single_meta - 40
							* @hooked woocommerce_template_single_sharing - 50
							*/
							do_action( 'woocommerce_single_product_summary' );
							?>

<?php
    /*if ( $wr_catalog_mode && $wr_show_button ) {
        echo '<div class="p-single-action pdb20 mgb20 nitro-line">';
        echo '<span>';
        if ( $wr_show_button_action == 'simple' ) {
            echo '<a target="_blank" rel="noopener noreferrer" class="button wr-btn wr-btn-solid" href="' . esc_attr( $wr_show_button_text ) . '">' . esc_attr( $wr_nitro_options['wc_archive_catalog_mode_button_text'] ) . '</a>';
        } else {
            echo '<a class="button wr-btn wr-btn-solid wr-open-cf7" href="#wr-cf7-form">' . esc_attr( $wr_nitro_options['wc_archive_catalog_mode_button_text'] ) . '</a>';
            echo '<div id="wr-cf7-form" class="mfp-hide">';
            echo do_shortcode( '[contact-form-7 id="' . esc_attr( $wr_nitro_options['wc_archive_catalog_mode_button_action_cf7'] ) . '"]' );
            echo '</div>';
        }
        echo '</span>';
        echo '</div>';
    }*/
    ?>

<?php
if(!(is_product() && has_term( 'Mattresses', 'product_cat' ))) { ?>

							<!-- This is Zaheer Ahmed Devveloped Area -->
							<div class="woocommerce-tabs wc-tabs-wrapper">
								<ul class="tabs wc-tabs">
									<li class="description_tab active hidden">
										<a href="#tab-description" class="tab-heading body_color">Description</a>
									</li>
								</ul>
								<div class="panel entry-content wc-tab" id="tab-description" style="display: block;">

									<h2>Description</h2>

									<div class="container">
										<div class="vc_row wpb_row vc_row-fluid product-container-wrapper vc_custom_1532361329563 vc_column-gap-35 vc_row-o-equal-height vc_row-flex">
											<div class="bg-img-single-product-discription wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill">
												<div class="vc_column-inner vc_custom_1528787267940">
													<div class="wpb_wrapper">
														<div class="wpb_single_image wpb_content_element vc_align_left   single-product-live-img">

															<figure class="wpb_wrapper vc_figure right">
																<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="300" height="400" src="<?php echo get_field('des_image');?>" class="vc_single_image-img attachment-full" alt="" srcset="<?php echo get_field('des_image');?> 300w, <?php echo get_field('des_image');?> 225w" sizes="(max-width: 300px) 100vw, 300px">
																</div>
															</figure>
														</div>
													</div>
												</div>
											</div>
											<div class="product-drcpt-row wpb_column vc_column_container vc_col-sm-6">
												<div class="vc_column-inner ">
													<div class="wpb_wrapper">
														<div class="vc_row wpb_row vc_inner vc_row-fluid">
															<div class="product-inner-section-rows wpb_column vc_column_container vc_col-sm-12">
																<div class="vc_column-inner ">
																	<div class="wpb_wrapper"><h2 style="text-align: center;font-family:Abril Fatface;font-weight:400;font-style:normal" class="vc_custom_heading product-sub-headings">OVERVIEW</h2>
																		<div id="nitro_custom_css_696395090" class="pr nitro-heading tc">
																			<div class="heading"><h1><?php echo get_field('des_short');?></h1>
																			</div>
																			<div class="sep line top">
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
														<div class="vc_wp_text wpb_content_element single-page-dsp-para">
															<div class="widget widget_text">
																<div class="textwidget"><p></p>
																	<p style="text-align: center;"><?php echo get_field('des_long');?></p>
																	<p>
																	</p></div>
																</div>
															</div>
															<!-- <div id="nitro_custom_css_1016718905" class="social-bar single-page-dsp-para-icon outline_circle small"><a class="facebook dib pr tc mgr10 mgb10" href="#"><i class="fa fa-facebook"></i><span class="tooltip ab ts-03">facebook</span></a><a class="instagram dib pr tc mgr10 mgb10" href="#"><i class="fa fa-instagram"></i><span class="tooltip ab ts-03">instagram</span></a>
															</div> -->

                              <!--<a href="<?php //echo get_field('product_spec_sheet');?>" download="Spec-Sheet">-->
                                <div class="wpb_wrapper">
                                  <h2 style="text-align: center;font-family:Abril Fatface;font-weight:400;font-style:normal" class="vc_custom_heading product-sub-headings"><a href="<?php the_field('des_specs'); ?>" >Spec Sheet</a></h2>
                                </div>
                              </a>

														</div>
													</div>
												</div>
											</div>
										</div>

<!-- This is Container for Finishes Section -->
<?php /* This Area Handle Sizes from ACF Pluginn, In case no Sizes Included, Section will be Skipped */
  if( have_rows('fin') ): ?>
										<div class="container">
											<div class="vc_row wpb_row vc_row-fluid single-product-help vc_custom_1528787046787 vc_row-has-fill">
												<div class="product-inner-section-rows wpb_column vc_column_container vc_col-sm-12">
													<div class="vc_column-inner ">
														<div class="wpb_wrapper container">
															<div id="nitro_custom_css_1119196386" class="pr nitro-heading single-product-help-subtitle tc">
																<div class="heading"><h3>FINISHES</h3>
																</div>
																<div class="sep line top">
																</div>
															</div>
                              <?php

                              // check if the repeater field has rows of data
                              // if( have_rows('finishes') ):

                              // loop through the rows of data
                              while ( have_rows('fin') ) : the_row();?>
															<div class="vc_row wpb_row vc_inner vc_row-fluid">
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading"><?php echo the_sub_field('fin_name_1');?></h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo the_sub_field('fin_image_1');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo the_sub_field('fin_image_1');?> 430w, <?php echo the_sub_field('fin_image_1');?> 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading"><?php echo the_sub_field('fin_name_2');?></h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo the_sub_field('fin_image_2');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo the_sub_field('fin_image_2');?> 430w, <?php echo the_sub_field('fin_image_2');?> 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading"><?php echo the_sub_field('fin_name_3');?></h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo the_sub_field('fin_image_3');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo the_sub_field('fin_image_3');?> 430w, <?php echo the_sub_field('fin_image_3');?> 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading"><?php echo the_sub_field('fin_name_4');?></h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo the_sub_field('fin_image_4');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo the_sub_field('fin_image_4');?> 430w, <?php echo the_sub_field('fin_image_4');?> 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading"><?php echo the_sub_field('fin_name_5');?></h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('fin_image_5');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo the_sub_field('fin_image_5');?> 430w, <?php echo the_sub_field('fin_image_5');?> 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<!-- <div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL6</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php //echo get_field('product_finishes_6');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-1.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-1-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
															<div class="vc_row wpb_row vc_inner vc_row-fluid">
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL1</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_7');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-9.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-9-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL2</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_8');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-7.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-7-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL3</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_9');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-4.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-4-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL4</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_10');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-grey-leather-aussie-royal-grey_2.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-grey-leather-aussie-royal-grey_2-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL5</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_11');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-2.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-2-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL6</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_12');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-1.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-1-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
															<div class="vc_row wpb_row vc_inner vc_row-fluid">
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL1</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_13');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-9.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-9-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL2</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_14');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-7.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-7-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL3</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_15');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-4.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-4-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL4</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_16');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-grey-leather-aussie-royal-grey_2.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-grey-leather-aussie-royal-grey_2-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL5</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_17');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-2.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-2-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL6</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_18');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-1.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-1-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
															<div class="vc_row wpb_row vc_inner vc_row-fluid">
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL1</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_19');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-9.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-9-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL2</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_20');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-7.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-7-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL3</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishesproduct_finishes_21');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-4.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-4-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL4</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_22');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-grey-leather-aussie-royal-grey_2.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-grey-leather-aussie-royal-grey_2-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL5</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_23');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-2.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-2-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL6</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_25');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-1.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-1-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
															<div class="vc_row wpb_row vc_inner vc_row-fluid">
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL1</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_26');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-9.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-9-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL2</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_27');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-7.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-7-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL3</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_28');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-4.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-4-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL4</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_29');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-grey-leather-aussie-royal-grey_2.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-grey-leather-aussie-royal-grey_2-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL5</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo get_field('product_finishes_30');?>" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-2.jpg 430w, <?php echo get_field('product_finishing_30');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="wpb_column vc_column_container vc_col-sm-2">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
																				<h2 class="wpb_heading wpb_singleimage_heading">GL6</h2>
																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-1.jpg" class="vc_single_image-img attachment-large" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-1.jpg 430w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/dolvce-vita-finish-1-300x126.jpg 300w" sizes="(max-width: 430px) 100vw, 430px">
																					</div>
																				</figure>
																			</div>
																		</div>
																	</div>
																</div> -->
															</div>

                              <?php
                            endwhile;?>

														</div>
													</div>
												</div>
											</div>
										</div>

                    <?php /* This Area Handle Sizes from ACF Pluginn, In case no Sizes Included, Section will be Skipped */
                  endif; ?>

<!-- This Is Sizes & Measurements Chamber -->
<?php /* This Area Handle Sizes from ACF Pluginn, In case no Sizes Included, Section will be Skipped */
  if( have_rows('size') ): ?>
										<div class="container">
											<div class="vc_row wpb_row vc_row-fluid single-product-help vc_custom_1528787059489 vc_row-has-fill">
												<div class="wpb_column vc_column_container vc_col-sm-12">
													<div class="vc_column-inner ">
														<div class="wpb_wrapper container">
															<div id="nitro_custom_css_1362544203" class="pr nitro-heading single-product-help-subtitle tc">
																<div class="heading"><h3>SIZES &amp; MEASUREMENTS</h3>
																</div>
																<div class="sep line top">
																</div>
															</div>
															<div class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-content-middle vc_row-flex">
                                <?php //if( have_rows('sizes') ):
                                  while ( have_rows('size') ) : the_row(); ?>
																<div class="wpb_column vc_column_container vc_col-sm-4">
																	<div class="vc_column-inner ">
																		<div class="wpb_wrapper">
																			<div class="wpb_single_image wpb_content_element vc_align_center">

																				<figure class="wpb_wrapper vc_figure">
																					<div class="vc_single_image-wrapper   vc_box_border_grey"><img class="vc_single_image-img " src="<?php echo the_sub_field('size_image');?>" width="100" height="50" alt="1-seat_2" title="1-seat_2">
																					</div>
                                          <div class="widget widget_text"><h5 class="widgettitle"><?php echo the_sub_field('size_name');?></h5>
																				</figure>
																			</div>
																			<div class="vc_wp_text wpb_content_element single-disp-sizes">
																				<!-- <div class="widget widget_text"><h2 class="widgettitle"><?php //echo the_sub_field('sizes_name');?></h2> -->
																					<div class="textwidget"><p></p>
																						<p style="text-align: center;"><?php echo "Length";?>: <?php echo the_sub_field('size_length');?></p>
																						<p>
																						</p></div>

                                            <div class="textwidget"><p></p>
                                              <p style="text-align: center;"><?php echo "Width";?>: <?php echo the_sub_field('size_width');?></p>
                                              <p>
                                              </p></div>

                                              <div class="textwidget"><p></p>
                                                <p style="text-align: center;"><?php echo "Height";?>: <?php echo the_sub_field('size_height');?></p>
                                                <p>
                                                </p></div>

																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
                                  <?php
                                endwhile; ?>
																	<!-- <div class="wpb_column vc_column_container vc_col-sm-4">
																		<div class="vc_column-inner ">
																			<div class="wpb_wrapper">
																				<div class="wpb_single_image wpb_content_element vc_align_center">

																					<figure class="wpb_wrapper vc_figure">
																						<div class="vc_single_image-wrapper   vc_box_border_grey"><img class="vc_single_image-img " src="http://dolcevitahome.com.pk/wp-content/uploads/2018/04/2-seat_2-100x50.png" width="100" height="50" alt="2-seat_2" title="2-seat_2">
																						</div>
																					</figure>
																				</div>
																				<div class="vc_wp_text wpb_content_element single-disp-sizes">
																					<div class="widget widget_text"><h2 class="widgettitle"><?php //get_field('size_name');?></h2>
																						<div class="textwidget"><p></p>
																							<p style="text-align: center;"><?php //echo "Length";?> <?php //echo get_field('product_2_size');?></p>
																							<p>
																							</p></div>
																						</div>
																					</div>
																				</div>
																			</div>
																		</div> -->
																		<!-- <div class="wpb_column vc_column_container vc_col-sm-4">
																			<div class="vc_column-inner ">
																				<div class="wpb_wrapper">
																					<div class="wpb_single_image wpb_content_element vc_align_center">

																						<figure class="wpb_wrapper vc_figure">
																							<div class="vc_single_image-wrapper   vc_box_border_grey"><img class="vc_single_image-img " src="http://dolcevitahome.com.pk/wp-content/uploads/2018/04/3-seat_2-100x50.png" width="100" height="50" alt="3-seat_2" title="3-seat_2"></div>
																						</figure>
																					</div>
																					<div class="vc_wp_text wpb_content_element single-disp-sizes">
																						<div class="widget widget_text"><h2 class="widgettitle"><?php //get_field('size_name');?></h2>
																							<div class="textwidget"><p></p>
																								<p style="text-align: center;"><?php //echo get_field('product_3_size');?></p>
																								<p>
																								</p></div>
																							</div>
																						</div>
																					</div>
																				</div>
																			</div> -->
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
<?php endif; ?>

<!-- This id "How Can we Help" Chamber -->
													<div class="container">
														<div class="vc_row wpb_row vc_row-fluid single-product-help vc_custom_1528787094986 vc_row-has-fill">
															<div class="wpb_column vc_column_container vc_col-sm-12">
																<div class="vc_column-inner ">
																	<div class="wpb_wrapper container">
																		<div id="nitro_custom_css_625180031" class="pr nitro-heading single-product-help-subtitle tc">
																			<div class="heading"><h3>HOW CAN WE HELP?</h3>
																			</div>
																			<div class="sep line top">
																			</div>
																		</div>
																		<div class="vc_row wpb_row vc_inner vc_row-fluid">
																			<div class="wpb_column vc_column_container vc_col-sm-3">
																				<div class="vc_column-inner ">

																					<div class="wpb_wrapper container">
																						<div class="wpb_single_image wpb_content_element vc_align_center">

																							<figure class="wpb_wrapper vc_figure">
																								<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="144" height="144" src="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/hand-144x144.png" class="vc_single_image-img attachment-full" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/hand-144x144.png 144w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/hand-144x144-60x60.png 60w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/hand-144x144-100x100.png 100w" sizes="(max-width: 144px) 100vw, 144px">
																								</div>
																							</figure>
																						</div>
																						<div id="nitro_custom_css_892466878" class="pr nitro-heading help-icon-title tc">
																							<div class="heading hcwh-heading"><h4>GOT A QUESTION?</h4>
																							</div>
																							<div class="sep line bottom">
																							</div>
																						</div>
																						<div class="vc_wp_text wpb_content_element single-product-help-para">
																							<div class="widget widget_text">
																								<div class="textwidget"><p></p>
																									<p style="text-align: center;">If you’d like to talk to us, simply share your contact details and one of our designers will be in touch very soon.</p>
																									<p>
																									</p></div>
																								</div>
																							</div>
																							<div class="vc_btn3-container  single-product-help-btn vc_btn3-center">
																								<button onmouseleave="this.style.borderColor='#333333'; this.style.backgroundColor='transparent'; this.style.color='#333333'" onmouseenter="this.style.borderColor='#e8e7e2'; this.style.backgroundColor='#e8e7e2'; this.style.color='#333333';" style="border-color:#333333; color:#333333;" class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-square vc_btn3-style-outline-custom">CONTACT US</button>
																							</div>
																						</div>
																					</div>
																				</div>

                                        <div class="wpb_column vc_column_container vc_col-sm-3">
																					<div class="vc_column-inner ">
																						<div class="wpb_wrapper">
																							<div class="wpb_single_image wpb_content_element vc_align_center">

																								<figure class="wpb_wrapper vc_figure">
																									<div class="vc_single_image-wrapper   vc_box_border_grey"><img class="vc_single_image-img " src="http://dolcevitahome.com.pk/wp-content/uploads/2018/07/camera.png" width="144" height="144" alt="camera" title="camera">
																									</div>
																								</figure>
																							</div>
																							<div id="nitro_custom_css_797050154" class="pr nitro-heading help-icon-title tc">
																								<div class="heading hcwh-heading"><h4>CONSULT A DESIGNER</h4>
																								</div>
																								<div class="sep line bottom">
																								</div>
																							</div>
																							<!-- <div class="vc_wp_text wpb_content_element single-product-help-para">
																								<div class="heading hcwh-heading"><h4>STORE LOCATOR</h4>
																								</div>
																								<div class="sep line bottom">
																								</div>
																							</div> -->
																							<div class="vc_wp_text wpb_content_element single-product-help-para">
																								<div class="widget widget_text">
																									<div class="textwidget"><p></p>
																										<p style="text-align: center;">We offer a range of products in our stores. Find out what products are available at your closest store.</p>
																										<p>
																										</p></div>
																									</div>
																								</div>
																								<div class="vc_btn3-container  single-product-help-btn vc_btn3-center">
																									<button onmouseleave="this.style.borderColor='#333333'; this.style.backgroundColor='transparent'; this.style.color='#333333'" onmouseenter="this.style.borderColor='#e8e7e2'; this.style.backgroundColor='#e8e7e2'; this.style.color='#333333';" style="border-color:#333333; color:#333333;" class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-square vc_btn3-style-outline-custom">LIST OF STORES</button>
																								</div>
																							</div>
																						</div>
																					</div>
                                        <div class="wpb_column vc_column_container vc_col-sm-3">
																					<div class="vc_column-inner ">
																						<div class="wpb_wrapper">
																							<div class="wpb_single_image wpb_content_element vc_align_center">

																								<figure class="wpb_wrapper vc_figure">
																									<div class="vc_single_image-wrapper   vc_box_border_grey"><img class="vc_single_image-img " src="http://dolcevitahome.com.pk/wp-content/uploads/2018/07/camera.png" width="144" height="144" alt="camera" title="camera">
																									</div>
																								</figure>
																							</div>
																							<div id="nitro_custom_css_797050154" class="pr nitro-heading help-icon-title tc">
																								<div class="heading hcwh-heading"><h4>STORE LOCATOR</h4>
																								</div>
																								<div class="sep line bottom">
																								</div>
																							</div>
																							<!-- <div class="vc_wp_text wpb_content_element single-product-help-para">
																								<div class="heading hcwh-heading"><h4>CONSULT A DESIGNER</h4>
																								</div>
																								<div class="sep line bottom">
																								</div>
																							</div> -->
																							<div class="vc_wp_text wpb_content_element single-product-help-para">
																								<div class="widget widget_text">
																									<div class="textwidget"><p></p>
																										<p style="text-align: center;">We offer a range of products in our stores. Find out what products are available at your closest store.</p>
																										<p>
																										</p></div>
																									</div>
																								</div>
																								<div class="vc_btn3-container  single-product-help-btn vc_btn3-center">
																									<button onmouseleave="this.style.borderColor='#333333'; this.style.backgroundColor='transparent'; this.style.color='#333333'" onmouseenter="this.style.borderColor='#e8e7e2'; this.style.backgroundColor='#e8e7e2'; this.style.color='#333333';" style="border-color:#333333; color:#333333;" class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-square vc_btn3-style-outline-custom">LIST OF STORES</button>
																								</div>
																							</div>
																						</div>
																					</div>
																					<div class="wpb_column vc_column_container vc_col-sm-3">
																						<div class="vc_column-inner ">
																							<div class="wpb_wrapper">
																								<div class="wpb_single_image wpb_content_element vc_align_center">

																									<figure class="wpb_wrapper vc_figure">
																										<div class="vc_single_image-wrapper   vc_box_border_grey">
																											<img width="144" height="144" src="http://dolcevitahome.com.pk/wp-content/uploads/2018/07/newspaper.png" class="vc_single_image-img attachment-full" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/07/newspaper.png 144w, http://dolcevitahome.com.pk/wp-content/uploads/2018/07/newspaper-60x60.png 60w, http://dolcevitahome.com.pk/wp-content/uploads/2018/07/newspaper-100x100.png 100w" sizes="(max-width: 144px) 100vw, 144px">
																										</div>
																									</figure>
																								</div>
																								<div id="nitro_custom_css_160739987" class="pr nitro-heading help-icon-title tc">
																									<div class="heading hcwh-heading"><h4>BE INSPIRED</h4>
																									</div>
																									<div class="sep line bottom">
																									</div>
																								</div>
																								<div class="vc_wp_text wpb_content_element single-product-help-para">
																									<div class="widget widget_text">
																										<div class="textwidget"><p></p>
																											<p style="text-align: center;">If you love daring and authentic design as much as we do, sign up to our newsletter for the latest collections and events.</p>
																											<p>
																											</p>
																										</div>
																									</div>
																								</div>
																								<div class="vc_btn3-container  single-product-help-btn vc_btn3-center">
																									<button onmouseleave="this.style.borderColor='#333333'; this.style.backgroundColor='transparent'; this.style.color='#333333'" onmouseenter="this.style.borderColor='#e8e7e2'; this.style.backgroundColor='#e8e7e2'; this.style.color='#333333';" style="border-color:#333333; color:#333333;" class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-square vc_btn3-style-outline-custom">SIGN UP TO NEWSLETTER</button>
																								</div>
																							</div>
																						</div>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>

													<!-- This Is Zaheer Ahmed Developed Area -->

<?php } else ?>
<?php wc_get_template( 'woorockets/single-product/builder.php' ); ?>



													<?php
                                                     if ( $wr_catalog_mode && $wr_show_button ) {
                                                         echo '<div class="p-single-action pdb20 mgb20 nitro-line">';
                                                             echo '<span>';
                                                                 if ( $wr_show_button_action == 'simple' ) {
                                                                     echo '<a target="_blank" rel="noopener noreferrer" class="button wr-btn wr-btn-solid" href="' . esc_attr( $wr_show_button_text ) . '">' . esc_attr( $wr_nitro_options['wc_archive_catalog_mode_button_text'] ) . '</a>';
                                                                 } else {
                                                                     echo '<a class="button wr-btn wr-btn-solid wr-open-cf7" href="#wr-cf7-form">' . esc_attr( $wr_nitro_options['wc_archive_catalog_mode_button_text'] ) . '</a>';
                                                                     echo '<div id="wr-cf7-form" class="mfp-hide">';
                                                                         echo do_shortcode( '[contact-form-7 id="' . esc_attr( $wr_nitro_options['wc_archive_catalog_mode_button_action_cf7'] ) . '"]' );
                                                                     echo '</div>';
                                                                 }
                                                             echo '</span>';
                                                         echo '</div>';
                                                     }
													?>
													<div class="product-tabs accordion-tab">
														<?php //wc_get_template( 'single-product/tabs/tabs-accordion.php' ); ?>
													</div>
												</div>
											</div>
										</div>
									</div>

									<?php //wc_get_template( 'woorockets/single-product/builder.php' ); ?>

									<?php
									/**
									* woocommerce_after_single_product_summary hook.
									*
									* @hooked woocommerce_output_product_data_tabs - 10
									* @hooked woocommerce_upsell_display - 15
									* @hooked woocommerce_output_related_products - 20
									*/
									//remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );

									if(!(is_product() && has_term( 'Mattresses', 'product_cat' ))) :
										do_action( 'woocommerce_after_single_product_summary' );
									endif;
									?>
								</div>
							</div>


						</div><!-- #product-<?php the_ID(); ?> -->
