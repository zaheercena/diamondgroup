
<!-- <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script> -->
<style>
/* This is To Generate Colums Inline for Finishes and Sizes */

.column5 {
  float: left;
  padding-left: 15px;
  padding-right: 15px;
  width: 20%;
}
.column4 {
    text-align:center;
  float: left;
  width: 25%;
  padding-left: 15px;
  padding-right: 15px;
}

/* Clear floats after the columns */
.row:before {
  content: "";
  display: table;
  clear: both;
  margin-left: -15px;
  margin-right: 15px;
}

</style>
<?php

/**
* @version    1.0
* @package    WR_Theme
* @author     WooRockets Team <support@woorockets.com>
* @copyright  Copyright (C) 2014 WooRockets.com. All Rights Reserved.
* @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
*
* Websites: http://www.woorockets.com
*/

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

global $product, $post;

$wr_nitro_options = WR_Nitro::get_options();

// Get sale price dates
$countdown = get_post_meta( get_the_ID(), '_show_countdown', true );
$start     = get_post_meta( get_the_ID(), '_sale_price_dates_from', true );
$end       = get_post_meta( get_the_ID(), '_sale_price_dates_to', true );
$now       = date( 'd-m-y' );


$is_bookings = ( class_exists( 'WC_Bookings' ) && $product->is_type( 'booking' ) );
$class_gravity_form = WR_Nitro_Helper::check_gravityforms( $post->ID ) ? ' custom-gravity-form' : NULL;

// Catalog mode
$wr_catalog_mode = $wr_nitro_options['wc_archive_catalog_mode'];

// Show custom button
$wr_show_button = $wr_nitro_options['wc_archive_catalog_mode_button'];

// Custom button action
$wr_show_button_action = $wr_nitro_options['wc_archive_catalog_mode_button_action'];

// Custom button action text
$wr_show_button_text = $wr_nitro_options['wc_archive_catalog_mode_button_action_simple'];

//Get custom content
$wr_custom_content_position = $wr_nitro_options['wc_single_product_custom_content_position'];
$wr_custom_content_data		= $wr_nitro_options['wc_single_product_custom_content_data'];

//Get custom message for sale product
$mes = get_post_meta( get_the_ID(), '_message_product_sale', true );
?>
<div id="product-<?php the_ID(); ?>" <?php post_class( 'style-1' . ( is_customize_preview() ? ' customizable customize-section-product_single' : '' ) . $class_gravity_form ); ?>>
  <div class="p-single-top oh pr">
    <div class="p-single-images">
      <?php
      /**
      * woocommerce_before_single_product_summary hook
      *
      * @hooked woocommerce_show_product_sale_flash - 10
      * @hooked woocommerce_show_product_images - 20
      */
      do_action( 'woocommerce_before_single_product_summary' );
      ?>
    </div>
    <div class="p-single-info add-to-cart-outer-wrapper">
      <?php
      if ( $wr_nitro_options['wc_single_breadcrumb'] ) {
        echo '<div class="mgb10">';
        woocommerce_breadcrumb();
        echo '</div>';
      }
      ?>
      <?php
      /**
      * woocommerce_single_product_summary hook.
      *
      * @hooked woocommerce_template_single_title - 5
      * @hooked woocommerce_template_single_rating - 10
      * @hooked woocommerce_template_single_price - 10
      * @hooked woocommerce_template_single_excerpt - 20
      * @hooked woocommerce_template_single_add_to_cart - 30
      * @hooked woocommerce_template_single_meta - 40
      * @hooked woocommerce_template_single_sharing - 50
      */

      do_action( 'woocommerce_single_product_summary' );
      ?>
    </div>
    <?php if ( 'yes' == $countdown && $end && date( 'd-m-y', $start ) <= $now ) : ?>
      <div class="product__countdown pa bgw">
        <div class="wr-nitro-countdown fc jcsb tc aic" data-time='{"day": "<?php echo date( 'd', $end ); ?>", "month": "<?php echo date( 'm', $end ); ?>", "year": "<?php echo date( 'Y', $end ); ?>"}'>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <div class="p-single-middle clear">
    <div class="fl mgt10">
      <?php
      if ( class_exists( 'WR_Share_For_Discounts' ) ) {
        $product_id   = $product->get_id();
        $sfd          = get_option( 'wr_share_for_discounts' );
        $settings     = $sfd['enable_product_discount'];
        $product_data = WR_Share_For_Discounts::get_meta_data( $product_id );

        if ( $settings != 1 || $product_data['enable'] != 1 ) {
          echo WR_Nitro_Pluggable_WooCommerce::woocommerce_share();
        }
      } else {
        echo WR_Nitro_Pluggable_WooCommerce::woocommerce_share();
      }
      ?>
    </div>

    <?php
    if ( ! $is_bookings ) :
      echo '<div class="p-single-action fr clearfix">';
      woocommerce_template_single_add_to_cart();
      echo '</div>';
    endif;

    if ( $wr_catalog_mode && $wr_show_button ) {
      echo '<div class="p-single-action fr clearfix">';
      if ( $wr_show_button_action == 'simple' ) {
        echo '<a target="_blank" rel="noopener noreferrer" class="button wr-btn wr-btn-solid" href="' . esc_attr( $wr_show_button_text ) . '">' . esc_attr( $wr_nitro_options['wc_archive_catalog_mode_button_text'] ) . '</a>';
      } else {
        echo '<a class="button wr-btn wr-btn-solid wr-open-cf7" href="#wr-cf7-form">' . esc_attr( $wr_nitro_options['wc_archive_catalog_mode_button_text'] ) . '</a>';
        echo '<div id="wr-cf7-form" class="mfp-hide">';
        echo do_shortcode( '[contact-form-7 id="' . esc_attr( $wr_nitro_options['wc_archive_catalog_mode_button_action_cf7'] ) . '"]' );
        echo '</div>';
      }
      echo '</div>';
    }
    ?>

    <div class="p-meta tu fr mgt10 mgr10">
      <span class="availability mgl10">
        <?php $availability = $product->get_availability(); ?>
        <span class="meta-left"><?php esc_html_e( 'Availability:', 'wr-nitro' ); ?></span>
        <span class="stock <?php echo ( $product->is_in_stock() ? 'in-stock' : 'out-stock' ); ?>">
          <?php
          if ( version_compare( WC_VERSION, '3.0.0', '<' ) ) {
            if ( $product->manage_stock == 'yes' && ! empty( $availability['availability'] ) ) :
              echo esc_html( $availability['availability'] );
              elseif ( $product->manage_stock == 'no' && $product->is_in_stock() ) :
                esc_html_e( 'In Stock', 'wr-nitro' );
                else :
                  esc_html_e( 'Out Of Stock', 'wr-nitro' );
                endif;
              } else {
                if ( $product->get_manage_stock() && ! empty( $availability['availability'] ) ) :
                  echo esc_html( $availability['availability'] );
                  elseif ( ! $product->get_manage_stock() && $product->is_in_stock() ) :
                    esc_html_e( 'In Stock', 'wr-nitro' );
                    else :
                      esc_html_e( 'Out Of Stock', 'wr-nitro' );
                    endif;
                  }
                  ?>
                </span>
              </span>
            </div>
          </div>



          <?php if ( $is_bookings ) : ?>
            <div class="p-single-booking pdt50 pdb50">
              <div class="container">
                <?php woocommerce_template_single_add_to_cart(); ?>
              </div>
            </div>
          <?php endif; ?>
          <div class="p-single-bot">
            <!-- This is Zaheer Ahmed Devveloped Area -->
            <div class="woocommerce-tabs  wc-tabs-wrapper">
              <!-- <ul class="tabs wc-tabs">
                <li class="description_tab active">
                  <a href="#tab-description" class="tab-heading body_color">Description</a>
                </li>
              </ul> -->
              <div class="panel entry-content wc-tab" id="tab-description" style="display: block;">

                <h2>Description</h2>
<!-- Description Area Goes Here, OVERVIEW Section it is It Contains ACF Generated
Product Image, Description Short, Description Long, PDF Downloadable File -->
                <div class="container">
                  <div class="vc_row style-five-custom-css wpb_row vc_row-fluid product-container-wrapper vc_custom_1532361329563 vc_column-gap-35 vc_row-o-equal-height vc_row-flex">
                    <div class="bg-img-single-product-discription wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill">
                      <div class="vc_column-inner vc_custom_1528787267940">
                        <div class="wpb_wrapper">
                          <div class="wpb_single_image wpb_content_element vc_align_left   single-product-live-img">

                            <figure class="wpb_wrapper vc_figure right">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="300" height="400" src="<?php echo get_field('des_image');?>" class="vc_single_image-img attachment-full" alt="" srcset="<?php echo get_field('des_image');?> 300w, <?php echo get_field('des_image');?> 225w" sizes="(max-width: 300px) 100vw, 300px">
                              </div>
                            </figure>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="product-drcpt-row wpb_column vc_column_container vc_col-sm-6">
                      <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                          <div class="vc_row wpb_row vc_inner vc_row-fluid">
                            <div class="product-inner-section-rows id="overview-description-wrapper" wpb_column vc_column_container vc_col-sm-12">
                              <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                  <h2 style="text-align: center;font-family:Abril Fatface;font-weight:400;font-style:normal" class="vc_custom_heading product-sub-headings">OVERVIEW</h2>
                                  <div id="nitro_custom_css_696395090" class="pr nitro-heading tc">
                                    <div class="heading">
                                      <h1><?php echo get_field('des_short');?></h1>
                                    </div>
                                    <div class="sep line top">
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="vc_wp_text wpb_content_element single-page-dsp-para">
                            <div class="widget widget_text">
                              <div class="textwidget"><p></p>
                                <p style="text-align: center;"><?php echo get_field('des_long');?></p>
                                <p></p>
                              </div>
                            </div>
                          </div>

                          <?php if(get_field('des_specs')) : ?>
                              <div class="wpb_wrapper spec-sheet-wrapper">
                                <a href="<?php the_field('des_specs'); ?>" ><h2 style="text-align: center;font-family:Abril Fatface;font-weight:400;font-style:normal" class="vc_custom_heading product-sub-headings">Spec Sheet</h2></a>
                              </div>
                            </a>
                            <?php endif; ?>

                            <!-- <div id="nitro_custom_css_1016718905" class="social-bar single-page-dsp-para-icon outline_circle small"><a class="facebook dib pr tc mgr10 mgb10" href="#"><i class="fa fa-facebook"></i><span class="tooltip ab ts-03">facebook</span></a><a class="instagram dib pr tc mgr10 mgb10" href="#"><i class="fa fa-instagram"></i><span class="tooltip ab ts-03">instagram</span></a>
                          </div> -->
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
<!-- This Area Container Deals with Finises, If teir are Finishes coming from ACF Plugin oterwise Section will be Skipped Politelty -->

                <div class="container">
                  <div class="vc_row wpb_row vc_row-fluid single-product-help vc_custom_1528787046787 vc_row-has-fill">


                  <div class="container">
<div class="vc_row wpb_row vc_row-fluid single-product-help vc_custom_1528787046787 vc_row-has-fill">

<?php if( get_field('if_finishes_exist') ): ?>

                      <?php //if( have_rows('fin') ):
                            ?>

                    <div id="nitro_custom_css_1119196386" class="pr nitro-heading single-product-help-subtitle tc">
                      <div class="heading">
                        <h3>FINISHES</h3>
                      </div>
                      <div class="sep line top">
                      </div>
                    </div>

                    <div class="container-center-align" align="left">
                      <?php

                      // check if the repeater field has rows of data
                      // if( have_rows('finishes') ):

                      // loop through the rows of data
                      //while ( have_rows('fin') ) : the_row();?>
                      <div class="row">
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_1');?></h2>
                            <figure class="wpb_wrapper vc_figure finishes-image-wrapper">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_1');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_1');?> 430w, <?php echo the_sub_field('fin_image_1');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_2');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_2');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_2');?> 430w, <?php echo the_sub_field('fin_image_2');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_3');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_3');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_3');?> 430w, <?php echo the_sub_field('fin_image_3');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_4');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_4');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_4');?> 430w, <?php echo the_sub_field('fin_image_4');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_5');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_5');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_5');?> 430w, <?php echo the_sub_field('fin_image_5');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                      </div>

                      <!-- This is 2nd Row for the Finishes -->
                      <div class="row">
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_6');?></h2>
                            <figure class="wpb_wrapper vc_figure finishes-image-wrapper">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_6');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_6');?> 430w, <?php echo the_sub_field('fin_image_1');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_7');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_7');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_7');?> 430w, <?php echo the_sub_field('fin_image_2');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_8');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_8');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_8');?> 430w, <?php echo the_sub_field('fin_image_3');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_9');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_9');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_9');?> 430w, <?php echo the_sub_field('fin_image_4');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_10');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_10');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_10');?> 430w, <?php echo the_sub_field('fin_image_5');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                      </div>

                      <!-- This is 3rd Row for the Finishes -->
                      <div class="row">
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_11');?></h2>
                            <figure class="wpb_wrapper vc_figure finishes-image-wrapper">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_11');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_11');?> 430w, <?php echo the_sub_field('fin_image_1');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_12');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_12');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_12');?> 430w, <?php echo the_sub_field('fin_image_2');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_13');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_13');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_13');?> 430w, <?php echo the_sub_field('fin_image_3');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_14');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_14');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_14');?> 430w, <?php echo the_sub_field('fin_image_4');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_15');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_15');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_15');?> 430w, <?php echo the_sub_field('fin_image_5');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                      </div>

                      <!-- This is 4th Row for the Finishes -->
                      <div class="row">
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_16');?></h2>
                            <figure class="wpb_wrapper vc_figure finishes-image-wrapper">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_16');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_16');?> 430w, <?php echo the_sub_field('fin_image_1');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_17');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_17');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_17');?> 430w, <?php echo the_sub_field('fin_image_2');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_18');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_18');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_18');?> 430w, <?php echo the_sub_field('fin_image_3');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_19');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_19');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_19');?> 430w, <?php echo the_sub_field('fin_image_4');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_20');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_20');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_20');?> 430w, <?php echo the_sub_field('fin_image_5');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                      </div>

                      <!-- This is 5th Row for the Finishes -->
                      <div class="row">
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_21');?></h2>
                            <figure class="wpb_wrapper vc_figure finishes-image-wrapper">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_21');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_21');?> 430w, <?php echo the_sub_field('fin_image_1');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_22');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_22');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_22');?> 430w, <?php echo the_sub_field('fin_image_2');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_23');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_23');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_23');?> 430w, <?php echo the_sub_field('fin_image_3');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_24');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_24');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_24');?> 430w, <?php echo the_sub_field('fin_image_4');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_25');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_25');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_25');?> 430w, <?php echo the_sub_field('fin_image_5');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                      </div>

                      <!-- This is 6th Row for the Finishes -->
                      <div class="row">
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_26');?></h2>
                            <figure class="wpb_wrapper vc_figure finishes-image-wrapper">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_26');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_26');?> 430w, <?php echo the_sub_field('fin_image_1');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_27');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_27');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_27');?> 430w, <?php echo the_sub_field('fin_image_2');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_28');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_28');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_28');?> 430w, <?php echo the_sub_field('fin_image_3');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_29');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_29');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_29');?> 430w, <?php echo the_sub_field('fin_image_4');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                        <div class="column5">
                          <div class="wpb_single_image wpb_content_element vc_align_center   product-finishes-layout">
                            <h2 class="wpb_heading wpb_singleimage_heading"><?php echo ot_get_option('swatch_name_30');?></h2>
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="430" height="180" src="<?php echo ot_get_option('swatch_30');?>" class="vc_single_image-img attachment-large" alt="" srcset="<?php echo ot_get_option('swatch_30');?> 430w, <?php echo the_sub_field('fin_image_5');?> 300w" sizes="(max-width: 430px) 100vw, 430px"></div>
                            </figure>
                          </div>
                        </div>
                      </div>

                      <?php
                    //endwhile;
                    //endif;
                    ?>

                  </div>
                <?php endif; ?>


</div></div>

                <?php //endif; //}
                ?>


                <div class="container">
              <div class="vc_row wpb_row vc_row-fluid single-product-help vc_custom_1528787059489 vc_row-has-fill">


                <?php
                //if(the_sub_field('sizes')) {
              /* This Area Handle Sizes from ACF Pluginn, In case no Sizes Included, Section will be Skipped */
                if( have_rows('size') ): ?>




                <div class="wpb_column vc_column_container vc_col-sm-12">
                  <div class="vc_column-inner ">
                    <div class="wpb_wrapper container">
                      <div id="nitro_custom_css_1362544203" class="pr nitro-heading single-product-help-subtitle tc">
                        <div class="heading">
                          <h3>SIZES &amp; MEASUREMENTS</h3>
                        </div>
                        <div class="sep line top">
                        </div>
                      </div>
                      <div class="container-center-align" align="center">
                        <!-- This is Size Section with Proper ACF Integration -->
                        <!-- This Upper Section handle Colums Heading names like Length, Width, Height -->
                        <div class="row">

                          <div class="column4">
                            <h4 class="widgettitle"><?php get_field('size_name');?></h4>
                          </div>

                          <div class="column4">
                            <h5 class="widgettitle"><?php echo "Length";?></h5>
                          </div>
                          <div class="column4">
                            <h5 class="widgettitle"><?php echo "Width";?></h5>
                          </div>
                          <div class="column4">
                            <h5 class="widgettitle"><?php echo "Height";?></h5>
                          </div>
                        </div>
                        <!-- This Upper Section handle Dynamic ACF Entries of Name, Image, Length, Width, Height -->
                        <?php //if( have_rows('sizes') ):
                          while ( have_rows('size') ) : the_row(); ?>

                          <div class="row">
                            <div class="column4">
                              <h6 class="widgettitle">
                                <?php if(get_sub_field('size_image')) : ?>
                                <img class="vc_single_image-img " src="<?php echo the_sub_field('size_image');?>" width="100" height="50" alt="1-seat_2" title="1-seat_2">
                                <?php endif;?>
                                <?php echo the_sub_field('size_name');?></h6>
                            </div>
                            <div class="column4">
                              <!-- <img class="vc_single_image-img " src="<?php //echo get_field('size_image');?>" width="100" height="50" alt="1-seat_2" title="1-seat_2"> -->
                              <h6 class="widgettitle"><?php echo the_sub_field('size_length');?></h6>
                            </div>
                            <div class="column4">
                              <!-- <img class="vc_single_image-img " src="<?php //echo get_field('size_image');?>" width="100" height="50" alt="1-seat_2" title="1-seat_2"> -->
                              <h6 class="widgettitle"><?php echo the_sub_field('size_width');?></h6>
                            </div>
                            <div class="column4">
                              <!-- <img class="vc_single_image-img " src="<?php //echo get_field('size_image');?>" width="100" height="50" alt="1-seat_2" title="1-seat_2"> -->
                              <h6 class="widgettitle"><?php echo the_sub_field('size_height');?></h6>
                            </div>
                          </div>
                          <?php
                        endwhile;
                      endif; ?>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>


        </div>
      </div><!-- This is Ending of the Outer Container of Finishes -->
<!-- This Section deals "HOW CAN WE HELP?HOW CAN WE HELP?" Section, It's Hard-Coded in this Module  -->
          <div class="container" id="hcwh-wrapper">
            <div class="vc_row wpb_row vc_row-fluid single-product-help vc_custom_1528787094986 vc_row-has-fill">

<div class="container">
<div class="vc_row wpb_row vc_row-fluid single-product-help vc_custom_1528787094986 vc_row-has-fill">

<!-- This is to get Current Product URL -->
<?php
  global $wp;
  $current_url = home_url( add_query_arg( array(), $wp->request ) ); ?>

              <div class="wpb_column vc_column_container vc_col-sm-12">
                <div class="vc_column-inner ">
                  <div id="nitro_custom_css_625180031" class="pr nitro-heading single-product-help-subtitle tc">
                    <div class="heading">
                      <h3>HOW CAN WE HELP?</h3>
                    </div>
                    <div class="sep line top">
                    </div>
                  </div>


                  <div class="row">

                    <div class="column4">


                      <div class="vc_column-inner ">
                        <div class="wpb_wrapper container">
                          <div class="wpb_single_image wpb_content_element vc_align_center">
                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="144" height="144" src="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/hand-144x144.png" class="vc_single_image-img attachment-full" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/06/hand-144x144.png 144w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/hand-144x144-60x60.png 60w, http://dolcevitahome.com.pk/wp-content/uploads/2018/06/hand-144x144-100x100.png 100w" sizes="(max-width: 144px) 100vw, 144px">
                              </div>
                            </figure>
                          </div>
                          <div id="nitro_custom_css_892466878" class="pr nitro-heading help-icon-title tc">
                            <div class="heading hcwh-heading">
                              <h4>GOT A QUESTION?</h4>
                            </div>
                            <div class="sep line bottom">
                            </div>
                          </div>
                          <div class="vc_wp_text wpb_content_element single-product-help-para">
                            <div class="widget widget_text">
                              <div class="textwidget"><p></p>
                                <p style="text-align: center;">If you’d like to talk to us, simply share your contact details and one of our designers will be in touch very soon.</p>
                                <p></p>
                              </div>
                            </div>
                          </div>
                          <div class="vc_btn3-container  single-product-help-btn vc_btn3-center">
                            <button onmouseleave="this.style.borderColor='#333333'; this.style.backgroundColor='transparent'; this.style.color='#333333'" onmouseenter="this.style.borderColor='#e8e7e2'; this.style.backgroundColor='#e8e7e2'; this.style.color='#333333';" style="border-color:#333333; color:#333333;" class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-square vc_btn3-style-outline-custom">CONTACT US</button>
                          </div>
                        </div>
                      </div>


                    </div><!-- This is Column4 Div Ending -->
                    <div class="column4">

                      <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                          <div class="wpb_single_image wpb_content_element vc_align_center">

                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img class="vc_single_image-img " src="http://dolcevitahome.com.pk/wp-content/uploads/2018/07/camera.png" width="144" height="144" alt="camera" title="camera">
                              </div>
                            </figure>
                          </div>
                          <div id="nitro_custom_css_797050154" class="pr nitro-heading help-icon-title tc">
                            <div class="heading hcwh-heading">
                              <h4>CONSULT A DESIGNER</h4>
                            </div>
                            <div class="sep line bottom">
                            </div>
                          </div>
                          <div class="vc_wp_text wpb_content_element single-product-help-para">
                            <div class="widget widget_text">
                              <div class="textwidget">
                                <p></p>
                                <p style="text-align: center;">Book a consultation with one of our friendly and knowledgeable interior designer and discover the full collection.</p>
                                <p></p>
                              </div>
                            </div>
                          </div>
                          <div class="vc_btn3-container  single-product-help-btn vc_btn3-center">
                            <button onmouseleave="this.style.borderColor='#333333'; this.style.backgroundColor='transparent'; this.style.color='#333333'" onmouseenter="this.style.borderColor='#e8e7e2'; this.style.backgroundColor='#e8e7e2'; this.style.color='#333333';" style="border-color:#333333; color:#333333;" class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-square vc_btn3-style-outline-custom">BOOK NOW</button>
                          </div>
                        </div>
                      </div>

                    </div><!-- This is Column4 Div Ending -->
                    <div class="column4">

                      <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                          <div class="wpb_single_image wpb_content_element vc_align_center">

                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="144" height="144" src="http://dolcevitahome.com.pk/wp-content/uploads/2018/07/globe.png" class="vc_single_image-img attachment-full" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/07/globe.png 144w, http://dolcevitahome.com.pk/wp-content/uploads/2018/07/globe-60x60.png 60w, http://dolcevitahome.com.pk/wp-content/uploads/2018/07/globe-100x100.png 100w" sizes="(max-width: 144px) 100vw, 144px"></div>
                            </figure>
                          </div>
                          <div id="nitro_custom_css_562880779" class="pr nitro-heading help-icon-title tc">
                            <div class="heading hcwh-heading">
                              <h4>STORE LOCATOR</h4>
                            </div>
                            <div class="sep line bottom">
                            </div>
                          </div>
                          <div class="vc_wp_text wpb_content_element single-product-help-para">
                            <div class="widget widget_text">
                              <div class="textwidget">
                                <p></p>
                                <p style="text-align: center;">We offer a range of products in our stores. Find out what products are available at your closest store.</p>
                                <p>
                                </p>
                              </div>
                            </div>
                          </div>
                          <div class="vc_btn3-container  single-product-help-btn vc_btn3-center">
                            <button onclick="window.location.href='http://dolcevitahome.com.pk/store-locator/'" onmouseleave="this.style.borderColor='#333333'; this.style.backgroundColor='transparent'; this.style.color='#333333'" onmouseenter="this.style.borderColor='#e8e7e2'; this.style.backgroundColor='#e8e7e2'; this.style.color='#333333';" style="border-color:#333333; color:#333333;" class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-square vc_btn3-style-outline-custom">LIST OF STORES</button>
                          </div>
                        </div>
                      </div>

                    </div><!-- This is Column4 Div Ending -->
                    <div class="column4">

                      <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                          <div class="wpb_single_image wpb_content_element vc_align_center">

                            <figure class="wpb_wrapper vc_figure">
                              <div class="vc_single_image-wrapper   vc_box_border_grey">
                                <img width="144" height="144" src="http://dolcevitahome.com.pk/wp-content/uploads/2018/07/newspaper.png" class="vc_single_image-img attachment-full" alt="" srcset="http://dolcevitahome.com.pk/wp-content/uploads/2018/07/newspaper.png 144w, http://dolcevitahome.com.pk/wp-content/uploads/2018/07/newspaper-60x60.png 60w, http://dolcevitahome.com.pk/wp-content/uploads/2018/07/newspaper-100x100.png 100w" sizes="(max-width: 144px) 100vw, 144px">
                              </div>
                            </figure>
                          </div>
                          <div id="nitro_custom_css_160739987" class="pr nitro-heading help-icon-title tc">
                            <div class="heading hcwh-heading">
                              <h4>BE INSPIRED</h4>
                            </div>
                            <div class="sep line bottom">
                            </div>
                          </div>
                          <div class="vc_wp_text wpb_content_element single-product-help-para">
                            <div class="widget widget_text">
                              <div class="textwidget">
                                <p></p>
                                <p style="text-align: center;">If you love daring and authentic design as much as we do, sign up to our newsletter for the latest collections and events.</p>
                                <p>
                                </p>
                              </div>
                            </div>
                          </div>
                          <div class="vc_btn3-container  single-product-help-btn vc_btn3-center">
                            <!-- This is to Show popup on How Can we Help Chamber. Current Url have Current Product Url -->
                            <button onclick="window.location.href='<?php $current_url."/"."#mailmunch-pop-676306";?>'" onmouseleave="this.style.borderColor='#333333'; this.style.backgroundColor='transparent'; this.style.color='#333333'" onmouseenter="this.style.borderColor='#e8e7e2'; this.style.backgroundColor='#e8e7e2'; this.style.color='#333333';" style="border-color:#333333; color:#333333;" class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-square vc_btn3-style-outline-custom">SIGN UP TO NEWSLETTER</button>
                          </div>
                        </div>
                      </div>

                    </div><!-- This is Column4 Div Ending -->
                  </div><!-- This is Row4 Div Ending -->







                </div>
              </div>

</div>
</div><!-- Inner Container Div Ending -->

            </div>
          </div> <!-- This is Last Container Div Ending -->





      <!-- This Is Zaheer Ahmed Devveloped Area -->
      <?php //echo do_shortcode('[vc_row gap="35" equal_height="yes" css=".vc_custom_1532361329563{padding-right: 100px !important;padding-left: 100px !important;}" el_class="product-container-wrapper"]');?>
      <?php //echo do_shortcode('[vc_column width="1/2" css=".vc_custom_1528787267940{background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}" el_class="bg-img-single-product-discription"]');?>
      <?php //echo do_shortcode('[vc_single_image image="33629" img_size="full" el_class="single-product-live-img"]');?>
      <?php
      /**
      * woocommerce_after_single_product_summary hook.
      *
      * @hooked woocommerce_output_product_data_tabs - 10
      * @hooked woocommerce_upsell_display - 15
      * @hooked woocommerce_output_related_products - 20
      */
      do_action( 'woocommerce_after_single_product_summary' );
      //do_action( 'woocommerce_output_related_products' );
      ?>

      <?php //wc_get_template( 'woorockets/single-product/builder.php' ); ?>
    </div>

    <?php //wc_get_template( 'woorockets/single-product/floating-button.php' ); ?>


  </div><!-- #product-<?php the_ID(); ?> -->
